const InvitationSection = () => {
  return (
    <section id="invitation" className="py-20 md:py-28 bg-ivory relative">
      <div className="max-w-4xl mx-auto px-4 text-center">
        {/* Decorative top ornament */}
        <div className="reveal flex items-center justify-center mb-10">
          <span className="block w-12 h-px bg-gold/40" />
          <svg className="w-8 h-8 mx-3 text-gold/60" viewBox="0 0 24 24" fill="currentColor">
            <path d="M12 2L14.5 9.5L22 12L14.5 14.5L12 22L9.5 14.5L2 12L9.5 9.5L12 2Z" />
          </svg>
          <span className="block w-12 h-px bg-gold/40" />
        </div>

        <h2 className="reveal font-heading text-3xl md:text-5xl font-light text-foreground mb-8">
          Құрметті қонақтар!
        </h2>

        {/* Family photo */}
        <div className="reveal mb-10 max-w-2xl mx-auto">
          <div className="rounded-2xl overflow-hidden shadow-lg border-2 border-gold/15">
            <img
              src="/assets/family-photo.png"
              alt="Біздің отбасы — Қыз ұзатуға шақырамыз!"
              className="w-full h-auto object-cover"
            />
          </div>
        </div>

        <div className="reveal bg-white/80 backdrop-blur-sm rounded-2xl p-8 md:p-12 shadow-sm border border-gold/10">
          <p className="font-body text-base md:text-lg leading-relaxed text-foreground mb-6">
            Біздің отбасымыздың ең бақытты күндерінің бірі — сүйікті қызымыз Меруерттің қыз ұзату тойына 
            Сізді шын жүректен шақырамыз.
          </p>
          <p className="font-body text-base md:text-lg leading-relaxed text-foreground mb-6">
            Бұл қуанышты сәтті бірге бөлісіп, ақ батаңызды беріп, 
            той-думанға қатысуыңызды сұраймыз.
          </p>
          <p className="font-body text-base md:text-lg leading-relaxed text-foreground">
            Сіздің қатысуыңыз — біздің бақытымыз!
          </p>

          <div className="mt-8 flex items-center justify-center">
            <span className="block w-8 h-px bg-gold/30" />
            <span className="font-heading text-xl text-gold mx-4 italic">Меруерттың отбасы</span>
            <span className="block w-8 h-px bg-gold/30" />
          </div>
        </div>
      </div>
    </section>
  );
};

export default InvitationSection;