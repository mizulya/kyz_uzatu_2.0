import { useState, useRef } from 'react';
import { Music, Music2 } from 'lucide-react';

const FloatingMusicButton = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const toggleMusic = () => {
    if (!audioRef.current) {
      audioRef.current = new Audio('/assets/background-music.mp3');
      audioRef.current.loop = true;
      audioRef.current.volume = 0.4;
    }

    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play().catch(() => {
        // Autoplay blocked by browser
      });
    }
    setIsPlaying(!isPlaying);
  };

  return (
    <button
      onClick={toggleMusic}
      className="fixed bottom-6 right-6 z-[9999] w-14 h-14 rounded-full bg-gold/90 backdrop-blur-sm shadow-2xl border-2 border-gold-light flex items-center justify-center transition-all duration-300 hover:scale-110 hover:shadow-xl"
      style={{ position: 'fixed' }}
      aria-label={isPlaying ? 'Музыканы тоқтату' : 'Музыканы қосу'}
      title={isPlaying ? 'Музыканы тоқтату' : 'Музыканы қосу'}
    >
      {isPlaying ? (
        <Music2 className="w-7 h-7 text-white animate-bounce" />
      ) : (
        <Music className="w-7 h-7 text-white" />
      )}
    </button>
  );
};

export default FloatingMusicButton;