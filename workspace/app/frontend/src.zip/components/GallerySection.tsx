import { useState } from 'react';
import { X, ChevronLeft, ChevronRight } from 'lucide-react';

const photos = [
  {
    src: '/assets/meruert-animation.jpeg',
    alt: 'Меруерт — анимация стилінде',
    caption: 'Меруерт',
  },
  {
    src: '/assets/meruert-horse.png',
    alt: 'Меруерт атпен',
    caption: 'Меруерт',
  },
];

const GallerySection = () => {
  const [lightbox, setLightbox] = useState<number | null>(null);

  const goNext = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (lightbox !== null) {
      setLightbox((lightbox + 1) % photos.length);
    }
  };

  const goPrev = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (lightbox !== null) {
      setLightbox((lightbox - 1 + photos.length) % photos.length);
    }
  };

  return (
    <section id="gallery" className="py-20 md:py-28 bg-ivory relative">
      <div className="max-w-6xl mx-auto px-4">
        <div className="text-center mb-14">
          <h2 className="reveal font-heading text-3xl md:text-5xl font-light text-foreground mb-4">
            Фотогалерея
          </h2>
          <p className="reveal font-body text-sm text-foreground/80 tracking-wider uppercase">
            Бізбен бірге
          </p>
        </div>

        {/* Photo grid - adaptive with full photos visible */}
        <div className="reveal grid grid-cols-1 sm:grid-cols-2 gap-4 md:gap-6">
          {photos.map((photo, index) => (
            <div
              key={index}
              onClick={() => setLightbox(index)}
              className="group relative cursor-pointer overflow-hidden rounded-2xl bg-ivory"
            >
              <div className="w-full min-h-[300px] flex items-center justify-center py-4">
                <img
                  src={photo.src}
                  alt={photo.alt}
                  className="w-full h-auto max-h-[420px] object-contain transition-transform duration-700 group-hover:scale-[1.02]"
                />
              </div>
              {/* Caption overlay */}
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/50 to-transparent p-4 opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                <span className="font-body text-sm text-white/90 tracking-wide">
                  {photo.caption}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Lightbox with navigation */}
      {lightbox !== null && (
        <div
          className="fixed inset-0 z-[100] bg-black/90 flex items-center justify-center p-4"
          onClick={() => setLightbox(null)}
        >
          <button
            onClick={() => setLightbox(null)}
            className="absolute top-6 right-6 text-white/80 hover:text-white transition-colors z-10"
          >
            <X className="w-8 h-8" />
          </button>

          {/* Previous */}
          <button
            onClick={goPrev}
            className="absolute left-4 top-1/2 -translate-y-1/2 text-white/70 hover:text-white transition-colors z-10"
          >
            <ChevronLeft className="w-10 h-10" />
          </button>

          {/* Next */}
          <button
            onClick={goNext}
            className="absolute right-4 top-1/2 -translate-y-1/2 text-white/70 hover:text-white transition-colors z-10"
          >
            <ChevronRight className="w-10 h-10" />
          </button>

          <img
            src={photos[lightbox].src}
            alt={photos[lightbox].alt}
            className="max-w-full max-h-[85vh] object-contain rounded-lg shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          />

          {/* Photo counter */}
          <div className="absolute bottom-6 left-1/2 -translate-x-1/2 text-white/70 font-body text-sm">
            {lightbox + 1} / {photos.length}
          </div>
        </div>
      )}
    </section>
  );
};

export default GallerySection;