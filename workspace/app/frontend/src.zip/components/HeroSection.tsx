const HeroSection = () => {
  return (
    <section
      id="hero"
      className="relative h-screen max-h-[900px] flex items-center justify-center overflow-hidden"
    >
      {/* Background - soft gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-blush-light via-ivory to-champagne/30" />

      {/* Decorative borders */}
      <div className="absolute top-8 left-8 w-24 h-24 md:w-32 md:h-32 border-t-2 border-l-2 border-gold/40 rounded-tl-3xl" />
      <div className="absolute top-8 right-8 w-24 h-24 md:w-32 md:h-32 border-t-2 border-r-2 border-gold/40 rounded-tr-3xl" />
      <div className="absolute bottom-8 left-8 w-24 h-24 md:w-32 md:h-32 border-b-2 border-l-2 border-gold/40 rounded-bl-3xl" />
      <div className="absolute bottom-8 right-8 w-24 h-24 md:w-32 md:h-32 border-b-2 border-r-2 border-gold/40 rounded-br-3xl" />

      {/* Content */}
      <div className="relative z-10 text-center px-4 max-w-3xl mx-auto flex flex-col items-center">
        {/* Main photo of bride */}
        <div className="animate-fade-in mb-8" style={{ animationDelay: '0.3s' }}>
          <div className="w-48 h-48 md:w-64 md:h-64 rounded-full overflow-hidden border-4 border-gold/30 shadow-xl mx-auto">
            <img
              src="/assets/meruert-dress.png"
              alt="Меруерт"
              className="w-full h-full object-cover object-top"
            />
          </div>
        </div>

        <p className="font-body text-sm md:text-base tracking-[0.3em] uppercase text-gold mb-4 animate-fade-in" style={{ animationDelay: '0.5s' }}>
          Қыз ұзату тойына шақыру
        </p>

        <div className="animate-fade-in-up" style={{ animationDelay: '0.7s' }}>
          <h1 className="font-heading text-5xl md:text-7xl lg:text-8xl font-light text-foreground mb-2">
            Меруерт
          </h1>
          <p className="font-body text-sm md:text-base text-foreground mt-2 tracking-wide">
            Қыз ұзату салтанаты
          </p>
        </div>

        <p className="font-body text-sm md:text-base text-foreground mt-8 tracking-wider animate-fade-in" style={{ animationDelay: '1s' }}>
          19 қыркүйек 2026 жыл • Талдықорған
        </p>

        <div className="mt-10 animate-fade-in" style={{ animationDelay: '1.3s' }}>
          <a
            href="#invitation"
            onClick={(e) => { e.preventDefault(); document.querySelector('#invitation')?.scrollIntoView({ behavior: 'smooth' }); }}
            className="inline-block px-8 py-3 border border-gold text-gold font-body text-sm tracking-wider uppercase hover:bg-gold hover:text-white transition-all duration-500 rounded-full"
          >
            Шақыруды оқу
          </a>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-float">
          <div className="w-6 h-10 rounded-full border-2 border-gold/40 flex items-start justify-center p-1.5">
            <div className="w-1.5 h-3 rounded-full bg-gold/60 animate-bounce" />
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;