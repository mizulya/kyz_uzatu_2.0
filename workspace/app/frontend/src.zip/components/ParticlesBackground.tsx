import { useEffect, useRef } from 'react';

const ParticlesBackground = () => {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const createParticle = () => {
      const particle = document.createElement('div');
      const size = Math.random() * 6 + 2;
      const left = Math.random() * 100;
      const duration = Math.random() * 10 + 15;
      const delay = Math.random() * 5;

      particle.style.cssText = `
        position: fixed;
        width: ${size}px;
        height: ${size}px;
        background: radial-gradient(circle, rgba(201, 169, 110, 0.6), rgba(201, 169, 110, 0));
        border-radius: 50%;
        left: ${left}%;
        bottom: -10px;
        pointer-events: none;
        animation: float-particle ${duration}s linear ${delay}s infinite;
        z-index: 1;
      `;

      container.appendChild(particle);
    };

    for (let i = 0; i < 20; i++) {
      createParticle();
    }

    return () => {
      while (container.firstChild) {
        container.removeChild(container.firstChild);
      }
    };
  }, []);

  return <div ref={containerRef} className="fixed inset-0 pointer-events-none z-[1]" />;
};

export default ParticlesBackground;