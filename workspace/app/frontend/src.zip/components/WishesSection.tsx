const WishesSection = () => {
  return (
    <section className="py-20 md:py-28 bg-ivory relative">
      <div className="max-w-3xl mx-auto px-4 text-center">
        <div className="reveal flex items-center justify-center mb-10">
          <span className="block w-12 h-px bg-gold/40" />
          <svg className="w-8 h-8 mx-3 text-gold/60" viewBox="0 0 24 24" fill="currentColor">
            <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
          </svg>
          <span className="block w-12 h-px bg-gold/40" />
        </div>

        <h2 className="reveal font-heading text-3xl md:text-5xl font-light text-foreground/90 mb-8">
          Қонақтарға тілек
        </h2>

        <div className="reveal bg-white/80 backdrop-blur-sm rounded-2xl p-8 md:p-12 shadow-sm border border-gold/10">
          <p className="font-body text-base md:text-lg leading-relaxed text-foreground/70 mb-6">
            Құрметті қонақтар, Сіздің ең қымбат сыйлығыңыз — Сіздің қатысуыңыз бен жылы тілектеріңіз.
          </p>
          <p className="font-body text-base md:text-lg leading-relaxed text-foreground/70 mb-6">
            Егер сый жасағыңыз келсе, біз конвертті ұнатамыз 💌
          </p>
          <p className="font-body text-sm text-foreground/50 italic">
            Сіздің махаббатыңыз бен қолдауыңыз — ең үлкен байлық
          </p>
        </div>
      </div>
    </section>
  );
};

export default WishesSection;