const FooterSection = () => {
  return (
    <footer className="py-16 md:py-20 bg-white relative border-t border-gold/10">
      <div className="max-w-3xl mx-auto px-4 text-center">
        {/* Decorative ornament */}
        <div className="flex items-center justify-center mb-8">
          <span className="block w-16 h-px bg-gold/30" />
          <span className="font-heading text-3xl text-gold mx-4">✦</span>
          <span className="block w-16 h-px bg-gold/30" />
        </div>

        <h2 className="font-heading text-2xl md:text-4xl font-light text-foreground mb-4">
          Меруерт
        </h2>

        <p className="font-body text-base text-foreground/80 mb-2">
          19 қыркүйек 2026
        </p>

        <p className="font-body text-sm text-foreground/70 mb-8">
          Талдықорған, Қазақстан
        </p>

        <div className="bg-blush-light/50 rounded-2xl p-6 md:p-8 inline-block">
          <p className="font-heading text-xl md:text-2xl text-foreground italic">
            "Қыздың жолы — жарық жол"
          </p>
        </div>

        <div className="mt-12 pt-8 border-t border-gold/10">
          <p className="font-body text-xs text-foreground/60 tracking-wider">
            Тойға қатысқаныңызға алғыс білдіреміз ❤️
          </p>
        </div>
      </div>
    </footer>
  );
};

export default FooterSection;