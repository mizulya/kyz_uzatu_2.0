const timelineItems = [
  { time: '17:00', title: 'Қонақтарды қарсы алу', description: 'Тіркелу және сәлемдесу' },
  { time: '17:30', title: 'Ресми бөлім', description: 'Бата, тілектер' },
  { time: '17:00', title: 'Той-думан', description: 'Ас, ән-күй, би' },
  { time: '19:30', title: 'Қыз ұзату рәсімі', description: 'Дәстүрлі рәсімдер' },
  { time: '20:00', title: 'Концерттік бағдарлама', description: 'Әншілер, шоу-бағдарлама' },
  { time: '22:00', title: 'Қоштасу', description: 'Финалдық сөздер' },
];

const TimelineSection = () => {
  return (
    <section id="timeline" className="py-20 md:py-28 bg-champagne/20 relative">
      <div className="max-w-3xl mx-auto px-4">
        <div className="text-center mb-14">
          <h2 className="reveal font-heading text-3xl md:text-5xl font-light text-foreground/90 mb-4">
            Бағдарлама
          </h2>
          <p className="reveal font-body text-sm text-foreground/50 tracking-wider uppercase">
            Кештің тәртібі
          </p>
        </div>

        <div className="relative">
          {/* Vertical line */}
          <div className="absolute left-6 md:left-1/2 top-0 bottom-0 w-px bg-gold/20 -translate-x-1/2" />

          <div className="space-y-8">
            {timelineItems.map((item, index) => (
              <div
                key={item.time}
                className={`reveal relative flex items-start gap-6 ${
                  index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'
                }`}
              >
                {/* Dot */}
                <div className="absolute left-6 md:left-1/2 w-3 h-3 rounded-full bg-gold border-2 border-white shadow-sm -translate-x-1/2 mt-2 z-10" />

                {/* Content */}
                <div className={`ml-14 md:ml-0 md:w-[calc(50%-2rem)] ${index % 2 === 0 ? 'md:text-right md:pr-8' : 'md:text-left md:pl-8'}`}>
                  <div className="bg-white/80 backdrop-blur-sm rounded-xl p-5 shadow-sm border border-gold/10 transition-all duration-300 hover:shadow-md">
                    <span className="inline-block font-body text-xs font-medium text-gold tracking-wider uppercase mb-1">
                      {item.time}
                    </span>
                    <h3 className="font-heading text-lg font-medium text-foreground/85 mb-1">
                      {item.title}
                    </h3>
                    <p className="font-body text-sm text-foreground/50">
                      {item.description}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default TimelineSection;