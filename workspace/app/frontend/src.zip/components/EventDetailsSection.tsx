import { Calendar, Clock, MapPin } from 'lucide-react';

const EventDetailsSection = () => {
  const details = [
    {
      icon: Calendar,
      title: 'Күні',
      info: '19 қыркүйек 2026',
      sub: 'Сенбі',
    },
    {
      icon: Clock,
      title: 'Уақыты',
      info: '17:00',
      sub: 'Қонақтарды қарсы алу',
    },
    {
      icon: MapPin,
      title: 'Мекен-жайы',
      info: 'Талдықорған қаласы',
      sub: 'Ресторан GrandHall (жазғы зал SummerHall)',
    },
  ];

  return (
    <section id="details" className="py-20 md:py-28 bg-ivory relative">
      <div className="max-w-5xl mx-auto px-4">
        <div className="text-center mb-14">
          <h2 className="reveal font-heading text-3xl md:text-5xl font-light text-foreground mb-4">
            Той мәліметтері
          </h2>
          <p className="reveal font-body text-sm text-foreground/80 tracking-wider uppercase">
            Маңызды ақпарат
          </p>
        </div>

        <div className="reveal grid grid-cols-1 md:grid-cols-3 gap-6">
          {details.map((item) => (
            <div
              key={item.title}
              className="bg-white/80 backdrop-blur-sm rounded-2xl p-8 text-center shadow-sm border border-gold/10 transition-all duration-300 hover:shadow-md hover:-translate-y-1"
            >
              <div className="w-14 h-14 mx-auto mb-5 rounded-full bg-blush-light flex items-center justify-center">
                <item.icon className="w-6 h-6 text-gold" />
              </div>
              <h3 className="font-heading text-xl font-medium text-foreground mb-2">
                {item.title}
              </h3>
              <p className="font-body text-lg font-medium text-gold mb-1">
                {item.info}
              </p>
              <p className="font-body text-sm text-foreground/80">
                {item.sub}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default EventDetailsSection;