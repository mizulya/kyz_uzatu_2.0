import { Navigation } from 'lucide-react';

const MapSection = () => {
  return (
    <section className="py-16 md:py-24 bg-white relative">
      <div className="max-w-5xl mx-auto px-4">
        <div className="text-center mb-10">
          <h2 className="reveal font-heading text-3xl md:text-5xl font-light text-foreground mb-4">
            Қалай жетуге болады
          </h2>
          <p className="reveal font-body text-sm text-foreground/80 tracking-wider">
            GrandHall Summer Hall, Талдықорған
          </p>
        </div>

        <div className="reveal rounded-2xl overflow-hidden shadow-sm border border-gold/10">
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2900!2d78.3738!3d45.0156!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNDXCsDAwJzU2LjIiTiA3OMKwMjInMjUuNyJF!5e0!3m2!1sen!2skz!4v1"
            width="100%"
            height="350"
            style={{ border: 0 }}
            allowFullScreen
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
            title="GrandHall Summer Hall, Талдықорған"
            className="w-full"
          />
        </div>

        <div className="reveal text-center mt-8">
          <a
            href="https://maps.google.com/?q=GrandHall+Taldykorgan"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-8 py-3 bg-gold text-white font-body text-sm tracking-wider uppercase rounded-full hover:bg-gold-dark transition-all duration-300 shadow-md hover:shadow-lg"
          >
            <Navigation className="w-4 h-4" />
            Навигацияны ашу
          </a>
        </div>
      </div>
    </section>
  );
};

export default MapSection;