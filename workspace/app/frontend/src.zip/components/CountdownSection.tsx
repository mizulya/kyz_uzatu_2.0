import { useState, useEffect } from 'react';

const CountdownSection = () => {
  const targetDate = new Date('2026-09-19T17:00:00').getTime();

  const calculateTimeLeft = () => {
    const now = new Date().getTime();
    const difference = targetDate - now;

    if (difference <= 0) {
      return { days: 0, hours: 0, minutes: 0, seconds: 0 };
    }

    return {
      days: Math.floor(difference / (1000 * 60 * 60 * 24)),
      hours: Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
      minutes: Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60)),
      seconds: Math.floor((difference % (1000 * 60)) / 1000),
    };
  };

  const [timeLeft, setTimeLeft] = useState(calculateTimeLeft());

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(calculateTimeLeft());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const timeBlocks = [
    { value: timeLeft.days, label: 'Күн' },
    { value: timeLeft.hours, label: 'Сағат' },
    { value: timeLeft.minutes, label: 'Минут' },
    { value: timeLeft.seconds, label: 'Секунд' },
  ];

  return (
    <section id="countdown" className="py-20 md:py-28 bg-champagne/30 relative">
      <div className="max-w-4xl mx-auto px-4 text-center">
        <h2 className="reveal font-heading text-3xl md:text-5xl font-light text-foreground mb-4">
          Тойға дейін
        </h2>
        <p className="reveal font-body text-sm text-foreground/80 tracking-wider uppercase mb-12">
          Күтіп отырмыз
        </p>

        <div className="reveal grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
          {timeBlocks.map((block) => (
            <div
              key={block.label}
              className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 md:p-8 shadow-sm border border-gold/10 transition-transform duration-300 hover:scale-105"
            >
              <span className="block font-heading text-4xl md:text-6xl font-light text-gold">
                {String(block.value).padStart(2, '0')}
              </span>
              <span className="block font-body text-xs md:text-sm text-foreground/80 mt-2 tracking-wider uppercase">
                {block.label}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CountdownSection;