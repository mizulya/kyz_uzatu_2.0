const dressItems = [
  {
    label: 'Ерлер',
    description: 'Классикалық костюм, галстук',
    icon: (
      <svg viewBox="0 0 64 64" className="w-16 h-16" fill="none" stroke="currentColor" strokeWidth="1.5">
        <path d="M32 8C28 8 25 11 25 15V20L20 56H44L39 20V15C39 11 36 8 32 8Z" />
        <path d="M25 20L32 24L39 20" />
        <path d="M32 24V56" />
        <path d="M28 8L32 14L36 8" />
      </svg>
    ),
    colors: ['#2C3E50', '#34495E', '#1A252F'],
  },
  {
    label: 'Әйелдер',
    description: 'Кешкі көйлек, элегантты стиль',
    icon: (
      <svg viewBox="0 0 64 64" className="w-16 h-16" fill="none" stroke="currentColor" strokeWidth="1.5">
        <path d="M32 8C29 8 27 10 27 13V18L22 28L27 30V56H37V30L42 28L37 18V13C37 10 35 8 32 8Z" />
        <path d="M27 30C27 30 24 40 22 56H42C40 40 37 30 37 30" />
        <circle cx="32" cy="22" r="1.5" fill="currentColor" />
      </svg>
    ),
    colors: ['#F8C8D4', '#F7E7CE', '#E8D5A8'],
  },
];

const DressCodeSection = () => {
  return (
    <section className="py-20 md:py-28 bg-ivory relative">
      <div className="max-w-4xl mx-auto px-4">
        <div className="text-center mb-14">
          <h2 className="reveal font-heading text-3xl md:text-5xl font-light text-foreground/90 mb-4">
            Дресс-код
          </h2>
          <p className="reveal font-body text-sm text-foreground/50 tracking-wider uppercase">
            Ұсынылатын стиль
          </p>
        </div>

        <div className="reveal grid grid-cols-1 md:grid-cols-2 gap-8">
          {dressItems.map((item) => (
            <div
              key={item.label}
              className="bg-white/80 backdrop-blur-sm rounded-2xl p-8 text-center shadow-sm border border-gold/10 transition-all duration-300 hover:shadow-md hover:-translate-y-1"
            >
              <div className="text-gold/70 flex justify-center mb-5">
                {item.icon}
              </div>
              <h3 className="font-heading text-2xl font-medium text-foreground/80 mb-2">
                {item.label}
              </h3>
              <p className="font-body text-sm text-foreground/50 mb-5">
                {item.description}
              </p>
              <div className="flex items-center justify-center gap-3">
                {item.colors.map((color) => (
                  <div
                    key={color}
                    className="w-8 h-8 rounded-full border-2 border-white shadow-sm"
                    style={{ backgroundColor: color }}
                    title={color}
                  />
                ))}
              </div>
            </div>
          ))}
        </div>

        <p className="reveal text-center font-body text-xs text-foreground/40 mt-8 tracking-wide">
          * Ақ түсті киім кимеуіңізді сұраймыз
        </p>
      </div>
    </section>
  );
};

export default DressCodeSection;