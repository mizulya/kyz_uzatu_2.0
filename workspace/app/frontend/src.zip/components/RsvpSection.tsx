import { useState } from 'react';
import { Send, CheckCircle } from 'lucide-react';

const RsvpSection = () => {
  const [formData, setFormData] = useState({
    name: '',
    attending: '',
  });
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.attending) {
      setError('Қатысатыныңызды таңдаңыз');
      return;
    }
    setIsLoading(true);
    setError('');

    try {
      const response = await fetch('https://formspree.io/f/mykrpkpl', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: JSON.stringify({
          name: formData.name,
          attending: formData.attending === 'yes' ? 'Иә, келемін ✅' : 'Жоқ, келе алмаймын ❌',
          _subject: `Қыз ұзату RSVP: ${formData.name} — ${formData.attending === 'yes' ? 'Келемін' : 'Келе алмаймын'}`,
        }),
      });

      if (response.ok) {
        setIsSubmitted(true);
      } else {
        setError('Қате болды. Қайта көріңіз.');
      }
    } catch {
      setError('Қате болды. Қайта көріңіз.');
    } finally {
      setIsLoading(false);
    }
  };

  if (isSubmitted) {
    return (
      <section id="rsvp" className="py-20 md:py-28 bg-white relative">
        <div className="max-w-lg mx-auto px-4 text-center">
          <div className="reveal">
            <CheckCircle className="w-16 h-16 text-gold mx-auto mb-6" />
            <h3 className="font-heading text-3xl text-foreground mb-4">
              Рахмет!
            </h3>
            <p className="font-body text-foreground/80">
              Сіздің жауабыңыз қабылданды. Сізді тойда көруге қуаныштымыз!
            </p>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="rsvp" className="py-20 md:py-28 bg-white relative">
      <div className="max-w-lg mx-auto px-4">
        <div className="text-center mb-14">
          <h2 className="reveal font-heading text-3xl md:text-5xl font-light text-foreground mb-4">
            Тойға келесіз бе?
          </h2>
          <p className="reveal font-body text-sm text-foreground/80 tracking-wider uppercase">
            Жауабыңызды күтеміз
          </p>
        </div>

        <form onSubmit={handleSubmit} className="reveal space-y-6">
          {/* Name */}
          <div>
            <label className="block font-body text-sm text-foreground mb-2">
              Аты-жөніңіз
            </label>
            <input
              type="text"
              required
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full px-4 py-3 rounded-xl border border-gold/20 bg-ivory/50 font-body text-sm focus:outline-none focus:border-gold/50 transition-colors"
              placeholder="Аты-жөніңізді жазыңыз"
            />
          </div>

          {/* Attending - radio buttons */}
          <div>
            <label className="block font-body text-sm text-foreground mb-3">
              Қатысасыз ба?
            </label>
            <div className="flex gap-4">
              <label
                className={`flex-1 flex items-center justify-center gap-2 py-4 rounded-xl border-2 cursor-pointer transition-all font-body text-sm ${
                  formData.attending === 'yes'
                    ? 'border-gold bg-gold/10 text-gold'
                    : 'border-gold/20 bg-ivory/50 text-foreground/80 hover:border-gold/40'
                }`}
              >
                <input
                  type="radio"
                  name="attending"
                  value="yes"
                  checked={formData.attending === 'yes'}
                  onChange={(e) => setFormData({ ...formData, attending: e.target.value })}
                  className="sr-only"
                />
                <span className="text-lg">✅</span>
                Келемін
              </label>
              <label
                className={`flex-1 flex items-center justify-center gap-2 py-4 rounded-xl border-2 cursor-pointer transition-all font-body text-sm ${
                  formData.attending === 'no'
                    ? 'border-gold bg-gold/10 text-gold'
                    : 'border-gold/20 bg-ivory/50 text-foreground/80 hover:border-gold/40'
                }`}
              >
                <input
                  type="radio"
                  name="attending"
                  value="no"
                  checked={formData.attending === 'no'}
                  onChange={(e) => setFormData({ ...formData, attending: e.target.value })}
                  className="sr-only"
                />
                <span className="text-lg">❌</span>
                Келе алмаймын
              </label>
            </div>
          </div>

          {error && (
            <p className="text-red-500 text-sm font-body text-center">{error}</p>
          )}

          {/* Submit */}
          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-4 rounded-xl bg-gold text-white font-body text-sm tracking-wider uppercase flex items-center justify-center gap-2 hover:bg-gold/90 transition-colors disabled:opacity-50"
          >
            {isLoading ? (
              'Жіберілуде...'
            ) : (
              <>
                <Send className="w-4 h-4" />
                Жауап беру
              </>
            )}
          </button>
        </form>
      </div>
    </section>
  );
};

export default RsvpSection;