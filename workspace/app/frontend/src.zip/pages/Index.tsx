import { useEffect } from 'react';
import Navigation from '@/components/Navigation';
import HeroSection from '@/components/HeroSection';
import InvitationSection from '@/components/InvitationSection';
import CountdownSection from '@/components/CountdownSection';
import EventDetailsSection from '@/components/EventDetailsSection';
import MapSection from '@/components/MapSection';

import GallerySection from '@/components/GallerySection';
import RsvpSection from '@/components/RsvpSection';
import WishesSection from '@/components/WishesSection';
import FooterSection from '@/components/FooterSection';
import FloatingMusicButton from '@/components/FloatingMusicButton';
import ParticlesBackground from '@/components/ParticlesBackground';

const Index = () => {
  useEffect(() => {
    const elements = document.querySelectorAll('.reveal');

    // Mark elements below viewport as hidden for animation
    elements.forEach((el) => {
      const rect = el.getBoundingClientRect();
      if (rect.top > window.innerHeight) {
        el.classList.add('hidden-reveal');
      }
    });

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.remove('hidden-reveal');
            entry.target.classList.add('visible');
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.05, rootMargin: '0px 0px -20px 0px' }
    );

    elements.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  return (
    <div className="relative min-h-screen overflow-x-hidden">
      <ParticlesBackground />
      <Navigation />
      <FloatingMusicButton />
      <HeroSection />
      <InvitationSection />
      <CountdownSection />
      <EventDetailsSection />
      <MapSection />
      <GallerySection />
      <RsvpSection />
      <WishesSection />
      <FooterSection />
    </div>
  );
};

export default Index;