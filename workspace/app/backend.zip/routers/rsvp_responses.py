import json
import logging
from typing import List, Optional

from datetime import datetime, date

from fastapi import APIRouter, Body, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from services.rsvp_responses import Rsvp_responsesService

# Set up logging
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/entities/rsvp_responses", tags=["rsvp_responses"])


# ---------- Pydantic Schemas ----------
class Rsvp_responsesData(BaseModel):
    """Entity data schema (for create/update)"""
    name: str
    phone: str = None
    attending: bool
    guest_count: int = None


class Rsvp_responsesUpdateData(BaseModel):
    """Update entity data (partial updates allowed)"""
    name: Optional[str] = None
    phone: Optional[str] = None
    attending: Optional[bool] = None
    guest_count: Optional[int] = None


class Rsvp_responsesResponse(BaseModel):
    """Entity response schema"""
    id: int
    name: str
    phone: Optional[str] = None
    attending: bool
    guest_count: Optional[int] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class Rsvp_responsesListResponse(BaseModel):
    """List response schema"""
    items: List[Rsvp_responsesResponse]
    total: int
    skip: int
    limit: int


class Rsvp_responsesBatchCreateRequest(BaseModel):
    """Batch create request"""
    items: List[Rsvp_responsesData]


class Rsvp_responsesBatchUpdateItem(BaseModel):
    """Batch update item"""
    id: int
    updates: Rsvp_responsesUpdateData


class Rsvp_responsesBatchUpdateRequest(BaseModel):
    """Batch update request"""
    items: List[Rsvp_responsesBatchUpdateItem]


class Rsvp_responsesBatchDeleteRequest(BaseModel):
    """Batch delete request"""
    ids: List[int]


# ---------- Routes ----------
@router.get("", response_model=Rsvp_responsesListResponse)
async def query_rsvp_responsess(
    query: str = Query(None, description='Query conditions as JSON, e.g. {"id":2} or {"id":{"$gte":2}}'),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    """Query rsvp_responsess with filtering, sorting, and pagination"""
    logger.debug(f"Querying rsvp_responsess: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")
    
    service = Rsvp_responsesService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")
        
        result = await service.get_list(
            skip=skip, 
            limit=limit,
            query_dict=query_dict,
            sort=sort,
        )
        logger.debug(f"Found {result['total']} rsvp_responsess")
        return result
    except HTTPException:
        raise
    except ValueError as e:
        logger.warning(f"Invalid rsvp_responses query: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error querying rsvp_responsess: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/all", response_model=Rsvp_responsesListResponse)
async def query_rsvp_responsess_all(
    query: str = Query(None, description='Query conditions as JSON, e.g. {"id":2} or {"id":{"$gte":2}}'),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    # Query rsvp_responsess with filtering, sorting, and pagination without user limitation
    logger.debug(f"Querying rsvp_responsess: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")

    service = Rsvp_responsesService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")

        result = await service.get_list(
            skip=skip,
            limit=limit,
            query_dict=query_dict,
            sort=sort
        )
        logger.debug(f"Found {result['total']} rsvp_responsess")
        return result
    except HTTPException:
        raise
    except ValueError as e:
        logger.warning(f"Invalid rsvp_responses query: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error querying rsvp_responsess: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/{id}", response_model=Rsvp_responsesResponse)
async def get_rsvp_responses(
    id: int,
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    """Get a single rsvp_responses by ID"""
    logger.debug(f"Fetching rsvp_responses with id: {id}, fields={fields}")
    
    service = Rsvp_responsesService(db)
    try:
        result = await service.get_by_id(id)
        if not result:
            logger.warning(f"Rsvp_responses with id {id} not found")
            raise HTTPException(status_code=404, detail="Rsvp_responses not found")
        
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching rsvp_responses {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("", response_model=Rsvp_responsesResponse, status_code=201)
async def create_rsvp_responses(
    data: Rsvp_responsesData,
    db: AsyncSession = Depends(get_db),
):
    """Create a new rsvp_responses"""
    logger.debug(f"Creating new rsvp_responses with data: {data}")
    
    service = Rsvp_responsesService(db)
    try:
        result = await service.create(data.model_dump())
        if not result:
            raise HTTPException(status_code=400, detail="Failed to create rsvp_responses")
        
        logger.info(f"Rsvp_responses created successfully with id: {result.id}")
        return result
    except ValueError as e:
        logger.error(f"Validation error creating rsvp_responses: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating rsvp_responses: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("/batch", response_model=List[Rsvp_responsesResponse], status_code=201)
async def create_rsvp_responsess_batch(
    request: Rsvp_responsesBatchCreateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Create multiple rsvp_responsess in a single request"""
    logger.debug(f"Batch creating {len(request.items)} rsvp_responsess")
    
    service = Rsvp_responsesService(db)
    results = []
    
    try:
        for item_data in request.items:
            result = await service.create(item_data.model_dump())
            if result:
                results.append(result)
        
        logger.info(f"Batch created {len(results)} rsvp_responsess successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch create: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch create failed: {str(e)}")


@router.put("/batch", response_model=List[Rsvp_responsesResponse])
async def update_rsvp_responsess_batch(
    request: Rsvp_responsesBatchUpdateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Update multiple rsvp_responsess in a single request"""
    logger.debug(f"Batch updating {len(request.items)} rsvp_responsess")
    
    service = Rsvp_responsesService(db)
    results = []
    
    try:
        for item in request.items:
            # Only include non-None values for partial updates
            update_dict = {k: v for k, v in item.updates.model_dump().items() if v is not None}
            result = await service.update(item.id, update_dict)
            if result:
                results.append(result)
        
        logger.info(f"Batch updated {len(results)} rsvp_responsess successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch update: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch update failed: {str(e)}")


@router.put("/{id}", response_model=Rsvp_responsesResponse)
async def update_rsvp_responses(
    id: int,
    data: Rsvp_responsesUpdateData,
    db: AsyncSession = Depends(get_db),
):
    """Update an existing rsvp_responses"""
    logger.debug(f"Updating rsvp_responses {id} with data: {data}")

    service = Rsvp_responsesService(db)
    try:
        # Only include non-None values for partial updates
        update_dict = {k: v for k, v in data.model_dump().items() if v is not None}
        result = await service.update(id, update_dict)
        if not result:
            logger.warning(f"Rsvp_responses with id {id} not found for update")
            raise HTTPException(status_code=404, detail="Rsvp_responses not found")
        
        logger.info(f"Rsvp_responses {id} updated successfully")
        return result
    except HTTPException:
        raise
    except ValueError as e:
        logger.error(f"Validation error updating rsvp_responses {id}: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error updating rsvp_responses {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.delete("/batch")
async def delete_rsvp_responsess_batch(
    request: Rsvp_responsesBatchDeleteRequest,
    db: AsyncSession = Depends(get_db),
):
    """Delete multiple rsvp_responsess by their IDs"""
    logger.debug(f"Batch deleting {len(request.ids)} rsvp_responsess")
    
    service = Rsvp_responsesService(db)
    deleted_count = 0
    
    try:
        for item_id in request.ids:
            success = await service.delete(item_id)
            if success:
                deleted_count += 1
        
        logger.info(f"Batch deleted {deleted_count} rsvp_responsess successfully")
        return {"message": f"Successfully deleted {deleted_count} rsvp_responsess", "deleted_count": deleted_count}
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch delete: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch delete failed: {str(e)}")


@router.delete("/{id}")
async def delete_rsvp_responses(
    id: int,
    db: AsyncSession = Depends(get_db),
):
    """Delete a single rsvp_responses by ID"""
    logger.debug(f"Deleting rsvp_responses with id: {id}")
    
    service = Rsvp_responsesService(db)
    try:
        success = await service.delete(id)
        if not success:
            logger.warning(f"Rsvp_responses with id {id} not found for deletion")
            raise HTTPException(status_code=404, detail="Rsvp_responses not found")
        
        logger.info(f"Rsvp_responses {id} deleted successfully")
        return {"message": "Rsvp_responses deleted successfully", "id": id}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting rsvp_responses {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")