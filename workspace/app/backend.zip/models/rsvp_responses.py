from core.database import Base
from datetime import datetime
from sqlalchemy import Boolean, Column, DateTime, Integer, String


class Rsvp_responses(Base):
    __tablename__ = "rsvp_responses"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    name = Column(String, nullable=False)
    phone = Column(String, nullable=True, default='', server_default='')
    attending = Column(Boolean, nullable=False)
    guest_count = Column(Integer, nullable=True, default=1, server_default='1')
    created_at = Column(DateTime(timezone=True), default=datetime.now)
    updated_at = Column(DateTime(timezone=True), default=datetime.now, onupdate=datetime.now)